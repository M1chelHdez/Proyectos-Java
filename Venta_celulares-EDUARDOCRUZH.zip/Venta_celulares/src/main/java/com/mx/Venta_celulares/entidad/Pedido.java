package com.mx.Venta_celulares.entidad;

public class Pedido {
	int cantidad;
	int id;
	public Pedido(int cantidad, int id) {
		this.cantidad = cantidad;
		this.id = id;
	}
	public Pedido() {
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Pedido [cantidad=" + cantidad + ", id=" + id + "]";
	}
	
	
}
