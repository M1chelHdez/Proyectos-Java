package com.mx.Venta_celulares.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mx.Venta_celulares.entidad.Celular;

public interface CelularesDao extends JpaRepository<Celular, Integer>{
	
	public void deleteByMarca(String marca);
	public void deleteByColor(String color);
	public void deleteByModelo(String modelo);
	public boolean existsByMarca(String marca);
	public boolean existsByColor(String color);
	public boolean existsByModelo(String modelo);
}
