package com.mx.Venta_celulares;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VentaCelularesApplication {

	public static void main(String[] args) {
		SpringApplication.run(VentaCelularesApplication.class, args);
	}

}
