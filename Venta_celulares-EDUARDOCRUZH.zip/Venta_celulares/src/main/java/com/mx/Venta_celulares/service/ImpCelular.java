package com.mx.Venta_celulares.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mx.Venta_celulares.dao.CelularesDao;
import com.mx.Venta_celulares.entidad.Celular;
import com.mx.Venta_celulares.entidad.Pedido;
import com.mx.Venta_celulares.respuesta.Respuesta;

@Service
public class ImpCelular implements Metodos {
@Autowired
CelularesDao celularDao;
	
	@Override
	public Respuesta guardar(Celular celular) {
		if(!celularDao.existsById(celular.getId())) {
			if(celular.getMarca().equals("XIAOMI") || celular.getMarca().equals("SAMSUM") || celular.getMarca().equals("IPHONE") || celular.getMarca().equals("ALCATEL") || celular.getMarca().equals("MOTOROLA")) {
				
				celular.setGanancias((celular.getPrecioVenta()-celular.getPrecioCompra())*celular.getCantidadVendida());
				//PUEDE DAR ERROR POR LA MARCA
				celularDao.save(celular);
				return new Respuesta("El celular fue guardado",(celular.getPrecioVenta()-celular.getPrecioCompra())*celular.getCantidadVendida(),true);
			}else {
				return new Respuesta("Marca no permitida",null,false);
			}
		}else {
			return new Respuesta("Ya existe el ID de los celulares",null,false);
		}
	}

	@Override
	public Respuesta editar(Celular celular) {
		if(celularDao.existsById(celular.getId())) {
			celular.setGanancias((celular.getPrecioVenta()-celular.getPrecioCompra())*celular.getCantidadVendida());
			celularDao.save(celular);
			return new Respuesta("el celular fue editado exitosamente",celular,false);
		}else {
			return new Respuesta("No existe el id con ese celular",null,false);
		}
	}

	@Override
	public Respuesta eliminar(Celular celular) {
		if(celularDao.existsById(celular.getId())) {
			celular = celularDao.findById(celular.getId()).orElse(null);
			celularDao.delete(celular);
			return new Respuesta("celular eliminado por id ",celular,true);
		}else if(celularDao.existsByMarca(celular.getMarca())) {
			celularDao.deleteByMarca(celular.getMarca());
			return new Respuesta("Se eliminaron todos los celulares de esa marca",celular.getMarca(),true);
		}else if(celularDao.existsByModelo(celular.getModelo())) {
			celularDao.deleteByModelo(celular.getModelo());
			return new Respuesta("Se eliminaron todos los celulares de ese modelo",celular.getModelo(),true);
		}else if(celularDao.existsByColor(celular.getColor())) {
			celularDao.deleteByColor(celular.getColor());
			return new Respuesta("Se eliminaron todos los celulares de ese color",celular.getColor(),true);
		}else {
			return new Respuesta("No se logro encontro celular por ningun atributo",null,false);
		}
	}

	@Override
	public Respuesta buscar(Celular celular) {
		if(celularDao.existsById(celular.getId())) {
			celular = celularDao.findById(celular.getId()).orElse(null);
			return new Respuesta("celular :",celular,true);
		}else if(celularDao.existsByMarca(celular.getMarca())) {
			return new Respuesta("celular :",celular,true);
		}else if(celularDao.existsByModelo(celular.getModelo())) {
			celularDao.deleteByModelo(celular.getModelo());
			return new Respuesta("celular :",celular,true);
		}else if(celularDao.existsByColor(celular.getColor())) {
			celularDao.deleteByColor(celular.getColor());
			return new Respuesta("celular :",celular,true);
		}else {
			return new Respuesta("No se logro encontro celular por ningun atributo",null,false);
		}
	}

	@Override
	public Respuesta listar() {
		if(celularDao.findAll().isEmpty()) {
			return new Respuesta("No hay celulares",null,false);
		}else {
			return new Respuesta("Los celulares son : ",celularDao.findAll(),true);
		}
	}

	@Override
	public Respuesta listarMarca(String marca) {
		List<Celular> celulares = new ArrayList<Celular>();
		if(celularDao.findAll().isEmpty()) {
			return new Respuesta("No hay celulares",null,false);
		}else {
			for(Celular c: celularDao.findAll()) {
				if(c.getMarca().equals(marca)) {
					celulares.add(c);
				}
			}
			return new Respuesta("Los celulares de esa marca son  : ",celulares,true);
		}
	}

	@Override
	public Respuesta pedido(Pedido pedido) {
		
		if(celularDao.existsById(pedido.getId())) {
			Celular celular=celularDao.findById(pedido.getId()).orElse(null);
			if(celular != null) {
				if(celular.getStockInventario()>pedido.getCantidad()) {
					celular.setStockInventario(celular.getStockInventario()-pedido.getCantidad());
					celularDao.save(celular);
					if(celular.getStockInventario()==1) {
						return new Respuesta("El stock es de 1 !cuidado! : ",celular.getStockInventario(),true);
					}
					return new Respuesta("Pedido exitoso celulares de : ",pedido.getCantidad() ,true);
				}
			}
		}
	return new Respuesta("No se encontro celular",null,false);
			
		
	}

}
