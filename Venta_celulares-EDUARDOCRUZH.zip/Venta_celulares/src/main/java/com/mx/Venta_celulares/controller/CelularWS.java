package com.mx.Venta_celulares.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mx.Venta_celulares.entidad.Celular;
import com.mx.Venta_celulares.entidad.Pedido;
import com.mx.Venta_celulares.respuesta.Respuesta;
import com.mx.Venta_celulares.service.ImpCelular;

@RestController
@CrossOrigin
@RequestMapping("Celulares")

public class CelularWS {
	
	@Autowired
	ImpCelular impC;
	
	@PostMapping("guardar")
	public Respuesta guardar(@RequestBody Celular celular) {
		return impC.guardar(celular);
	}
	@PostMapping("editar")
	public Respuesta editar(@RequestBody Celular celular) {
		return impC.editar(celular);
	}
	@PostMapping("eliminar")
	public Respuesta eliminar(@RequestBody Celular celular) {
		return impC.eliminar(celular);
	}
	@PostMapping("buscar")
	public Respuesta buscar(@RequestBody Celular celular) {
		return impC.buscar(celular);
	}
	@GetMapping("listar")
	public Respuesta listar() {
		return impC.listar();
	}
	@PostMapping("listarMarca")
	public Respuesta listarMarca(@RequestBody String marca) {
		return impC.listarMarca(marca);
	}
	@PostMapping("pedido")
	public Respuesta pedido(@RequestBody Pedido pedido) {
		return impC.pedido(pedido);
	}
}
