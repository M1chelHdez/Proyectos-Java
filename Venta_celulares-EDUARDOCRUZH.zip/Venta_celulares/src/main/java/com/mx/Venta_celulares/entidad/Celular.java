package com.mx.Venta_celulares.entidad;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="venta_celulares")
public class Celular {
@Id
@Column(name="id")
int id;
@Column(name="marca")
String marca;
@Column(name="modelo")
String modelo;
@Column(name="color")
String color;
@Column(name="ram")
String ram;
@Column(name="tamano")
String tamano;
@Column(name="procesador")
String procesador;
@Column(name="precio_compra")
int precioCompra;
@Column(name="precio_venta")
int precioVenta;
@Column(name="cantidad_vendida")
int cantidadVendida;
@Column(name="fecha_venta")
Date fechaVenta;
@Column(name="stock_inventario")
int stockInventario;
@Column(name="ganancias")
int ganancias;
public Celular() {
}
public Celular(int id, String marca, String modelo, String color, String ram, String tamano, String procesador,
		int precioCompra, int precioVenta, int cantidadVendida, Date fechaVenta, int stockInventario, int ganancias) {
	this.id = id;
	this.marca = marca;
	this.modelo = modelo;
	this.color = color;
	this.ram = ram;
	this.tamano = tamano;
	this.procesador = procesador;
	this.precioCompra = precioCompra;
	this.precioVenta = precioVenta;
	this.cantidadVendida = cantidadVendida;
	this.fechaVenta = fechaVenta;
	this.stockInventario = stockInventario;
	this.ganancias = ganancias;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getMarca() {
	return marca;
}
public void setMarca(String marca) {
	this.marca = marca;
}
public String getModelo() {
	return modelo;
}
public void setModelo(String modelo) {
	this.modelo = modelo;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}
public String getRam() {
	return ram;
}
public void setRam(String ram) {
	this.ram = ram;
}
public String getTamano() {
	return tamano;
}
public void setTamano(String tamano) {
	this.tamano = tamano;
}
public String getProcesador() {
	return procesador;
}
public void setProcesador(String procesador) {
	this.procesador = procesador;
}
public int getPrecioCompra() {
	return precioCompra;
}
public void setPrecioCompra(int precioCompra) {
	this.precioCompra = precioCompra;
}
public int getPrecioVenta() {
	return precioVenta;
}
public void setPrecioVenta(int precioVenta) {
	this.precioVenta = precioVenta;
}
public int getCantidadVendida() {
	return cantidadVendida;
}
public void setCantidadVendida(int cantidadVendida) {
	this.cantidadVendida = cantidadVendida;
}
public Date getFechaVenta() {
	return fechaVenta;
}
public void setFechaVenta(Date fechaVenta) {
	this.fechaVenta = fechaVenta;
}
public int getStockInventario() {
	return stockInventario;
}
public void setStockInventario(int stockInventario) {
	this.stockInventario = stockInventario;
}
public int getGanancias() {
	return ganancias;
}
public void setGanancias(int ganancias) {
	this.ganancias = ganancias;
}
@Override
public String toString() {
	return "Celular [id=" + id + ", marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", ram=" + ram
			+ ", tamano=" + tamano + ", procesador=" + procesador + ", precioCompra=" + precioCompra + ", precioVenta="
			+ precioVenta + ", cantidadVendida=" + cantidadVendida + ", fechaVenta=" + fechaVenta + ", stockInventario="
			+ stockInventario + ", ganancias=" + ganancias + "]";
}


	
}
