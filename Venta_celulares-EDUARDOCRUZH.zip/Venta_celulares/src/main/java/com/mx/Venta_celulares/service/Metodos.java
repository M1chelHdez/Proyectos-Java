package com.mx.Venta_celulares.service;

import com.mx.Venta_celulares.entidad.Celular;
import com.mx.Venta_celulares.entidad.Pedido;
import com.mx.Venta_celulares.respuesta.Respuesta;

public interface Metodos {

	public Respuesta guardar(Celular celular);
	public Respuesta editar(Celular celular);
	public Respuesta eliminar(Celular celular);
	public Respuesta buscar(Celular celular);
	public Respuesta listar();
	public Respuesta listarMarca(String marca);
	public Respuesta pedido(Pedido pedido);
}
