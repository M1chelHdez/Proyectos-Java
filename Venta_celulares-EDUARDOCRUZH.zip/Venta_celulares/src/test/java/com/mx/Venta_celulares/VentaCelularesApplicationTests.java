package com.mx.Venta_celulares;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VentaCelularesApplicationTests {

	@Test
	void contextLoads() {
	}

}
