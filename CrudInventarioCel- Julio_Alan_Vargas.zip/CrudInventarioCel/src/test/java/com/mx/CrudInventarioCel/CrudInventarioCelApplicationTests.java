package com.mx.CrudInventarioCel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudInventarioCelApplicationTests {

	@Test
	void contextLoads() {
	}

}
