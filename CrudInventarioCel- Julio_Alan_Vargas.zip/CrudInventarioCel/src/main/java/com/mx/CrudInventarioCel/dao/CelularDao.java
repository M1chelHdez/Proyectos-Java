package com.mx.CrudInventarioCel.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mx.CrudInventarioCel.dominio.Celulares;

import jakarta.transaction.Transactional;

@Repository
public interface CelularDao extends CrudRepository<Celulares, Integer> {

	// Listar por marca
	List<Celulares> findAllByMarca(String marca);

	// Listar por modelo
	List<Celulares> findAllByModelo(String modelo);

	// eliminarModelo
	@Transactional
	@Modifying
	void deleteByModelo(String modelo);

	// eliminarMarca
	@Transactional
	@Modifying
	void deleteByMarca(String marca);

	// buscar por marca
	Celulares findByMarca(String marca);

}
