package com.mx.CrudInventarioCel.dominio;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "VENTA_CELULARES")
@Data
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString

public class Celulares {
	/*	CREATE TABLE VENTA_CELULARES(
		ID NUMBER PRIMARY KEY,
		MARCA NVARCHAR2(50),
		MODELO NVARCHAR2(50),
		COLOR NVARCHAR2(50),
		RAM NVARCHAR2(50), --> 4 RAM
		TAMANO NVARCHAR2(50),
		PROCESADOR NVARCHAR2(50),
		PRECIO_COMPRA NUMBER,
		PRECIO_VENTA NUMBER,
		CANTIDAD_VENDIDA NUMBER,
		FECHA_VENTA DATE,
		STOCK_INVENTARIO NUMBER,
		GANANCIAS NUMBER,
		CHECK (MARCA IN ('XIAOMI','SAMSUM','IPHONE','ALCATEL','MOTOROLA'))
		);
*/
	@Id
	int id;
	String marca;
	String modelo;
	String color;
	String ram;
	String tamano;
	String procesador;
	@Column(name = "PRECIO_COMPRA" )
	double precioCompra;
	@Column(name = "PRECIO_VENTA" )
	double precioVenta;
	@Column(name = "CANTIDAD_VENDIDA" )
	int cantidadVendida;
	@JsonFormat(pattern = "dd/MM/YYYY HH:MM:SS", timezone = "America/Mexico_City")
	@Column(name = "FECHA_VENTA" )
	Date fechaVenta;
	@Column(name = "STOCK_INVENTARIO" )
	int stockInventario;
	double ganancia;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getRam() {
		return ram;
	}
	public void setRam(String ram) {
		this.ram = ram;
	}
	public String getTamano() {
		return tamano;
	}
	public void setTamano(String tamano) {
		this.tamano = tamano;
	}
	public String getProcesador() {
		return procesador;
	}
	public void setProcesador(String procesador) {
		this.procesador = procesador;
	}
	public double getPrecioCompra() {
		return precioCompra;
	}
	public void setPrecioCompra(double precioCompra) {
		this.precioCompra = precioCompra;
	}
	public double getPrecioVenta() {
		return precioVenta;
	}
	public void setPrecioVenta(double precioVenta) {
		this.precioVenta = precioVenta;
	}
	public int getCantidadVendida() {
		return cantidadVendida;
	}
	public void setCantidadVendida(int cantidadVendida) {
		this.cantidadVendida = cantidadVendida;
	}
	public Date getFechaVenta() {
		return fechaVenta;
	}
	public void setFechaVenta(Date fechaVenta) {
		this.fechaVenta = fechaVenta;
	}
	public int getStockInventario() {
		return stockInventario;
	}
	public void setStockInventario(int stockInventario) {
		this.stockInventario = stockInventario;
	}
	public double getGanancia() {
		return ganancia;
	}
	public void setGanancia(double ganancia) {
		this.ganancia = ganancia;
	}
	
	
}
