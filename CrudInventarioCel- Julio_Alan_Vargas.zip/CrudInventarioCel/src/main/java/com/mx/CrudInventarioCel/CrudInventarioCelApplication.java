package com.mx.CrudInventarioCel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudInventarioCelApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudInventarioCelApplication.class, args);
	}

}
