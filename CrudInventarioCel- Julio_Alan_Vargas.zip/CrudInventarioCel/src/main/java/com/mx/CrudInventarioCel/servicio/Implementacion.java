package com.mx.CrudInventarioCel.servicio;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mx.CrudInventarioCel.dao.CelularDao;
import com.mx.CrudInventarioCel.dominio.Celulares;
@Service
public class Implementacion implements Metodos {

	@Autowired
	CelularDao dao;
	
	@Override
	public void guardar(Celulares celular) {
		// TODO Auto-generated method stub
		dao.save(celular);
	}

	@Override
	public void editar(Celulares celular) {
		// TODO Auto-generated method stub
		dao.save(celular);
	}

	@Override
	public void eliminar(Celulares celular) {
		// TODO Auto-generated method stub
		List<Celulares> elim = new ArrayList<>();
		for (Celulares cel : listar()) {
			if (cel.getModelo().equals(celular.getModelo()) || cel.getMarca().equals(celular.getMarca())) {
				elim.add(cel);
			}
		}
		for (Celulares c : elim) {
			dao.delete(c);
		}
	}

	@Override
	public Celulares buscar(Celulares celular) {
		// TODO Auto-generated method stub
		return dao.findById(celular.getId()).orElseThrow(() -> new RuntimeException("No existe el celular"));
	}
	
	public List<Celulares> buscarModelo(String modelo) {
		List<Celulares> celu = dao.findAllByModelo(modelo);
		return celu;
	}

	public List<Celulares> buscarMarca(String marca) {
		List<Celulares> celu = dao.findAllByMarca(marca);
		return celu;
	}

	@Override
	public List<Celulares> listaMarca(Celulares celular) {
		// TODO Auto-generated method stub
		return dao.findAllByMarca(celular.getMarca());
	}

	@Override
	public List<Celulares> listar() {
		// TODO Auto-generated method stub
		return (List<Celulares>) dao.findAll();
	}

	@Override
	public void ventas(Celulares celular) {
		// TODO Auto-generated method stub
		
	}

}
