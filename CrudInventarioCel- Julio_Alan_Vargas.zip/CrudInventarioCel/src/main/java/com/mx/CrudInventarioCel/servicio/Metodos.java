package com.mx.CrudInventarioCel.servicio;

import java.util.List;

import com.mx.CrudInventarioCel.dominio.Celulares;

public interface Metodos {

	public void guardar(Celulares celular); //NO TIENE VALOR DE RETORNO
	
	public void editar(Celulares celular);
	public void eliminar(Celulares celular);
	public Celulares buscar(Celulares celular);
	
	public List<Celulares> listaMarca(Celulares celular);
	public List<Celulares> listar();
	
	public void ventas(Celulares celular);
	
	
	
}
