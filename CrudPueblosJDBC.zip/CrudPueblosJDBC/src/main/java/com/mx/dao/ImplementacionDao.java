package com.mx.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mx.dominio.Pueblos;
import com.mx.general.ConexionBD;
import com.mx.general.Metodos;

public class ImplementacionDao implements Metodos {

	ConexionBD bd = new ConexionBD();
	Pueblos pueblo = null;

	@Override
	public String guardar(Object obj) {
		// TODO Auto-generated method stub
		pueblo = (Pueblos) obj;

		// crear la conexion con un object
		Connection cone;
		// abrir la conexion --> PreparedStament --> mediante una delcaracion preparda
		PreparedStatement pst;
		// preparar la sentencia
		String query = "INSERT INTO PUEBLOS VALUES(?,?,?,?,?,?,?)";
		String resultado = null;
		try {
			// registrar la clase --> metodo forName() de la class --> me permite traer el
			// controlador
			Class.forName(bd.getDriver()); // permite registra la clase del controlador
			// abrir el objeto onexion --> de la clase DriveManager
			cone = DriverManager.getConnection(bd.getUrl(), bd.getUsuario(), bd.getPassword());
			// ejecuta la sentencia sql
			pst = cone.prepareStatement(query);

			pst.setInt(1, pueblo.getId());
			pst.setString(2, pueblo.getNombre());
			pst.setString(3, pueblo.getMunicipio());
			pst.setString(4, pueblo.getEstado());
			pst.setString(5, pueblo.getPais());
			pst.setInt(6, pueblo.getNum_h());
			pst.setString(7, pueblo.getRanking());

			int insert = pst.executeUpdate();

			if (insert > 0) {
				resultado = "1";
				System.out.println("Se guardo el pueblo magico " +" Estatus "+ resultado + pueblo.getNombre());
			} else {
				resultado = "0";
				System.out.println("No se guardo el pueblo magico " + insert);
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error al guardar");
		}

		return resultado;
	}

	@Override
	public String editar(Object obj) {
		pueblo = (Pueblos) obj;

		// crear la conexion con un object
		Connection cone;
		// abrir la conexion --> PreparedStament --> mediante una delcaracion preparda
		PreparedStatement pst;
		// preparar la sentencia
		String query = "UPDATE PUEBLOS SET NOMBRE=?,MUNICIPIO=?,ESTADO=?,PAIS=?,NUM_H=?,RANKING=? WHERE ID =?";
		String resultado = null;
		try {
			// registrar la clase --> metodo forName() de la class --> me permite traer el
			// controlador
			Class.forName(bd.getDriver()); // permite registra la clase del controlador
			// abrir el objeto onexion --> de la clase DriveManager
			cone = DriverManager.getConnection(bd.getUrl(), bd.getUsuario(), bd.getPassword());
			// ejecuta la sentencia sql
			pst = cone.prepareStatement(query);

			pst.setString(1, pueblo.getNombre());
			pst.setString(2, pueblo.getMunicipio());
			pst.setString(3, pueblo.getEstado());
			pst.setString(4, pueblo.getPais());
			pst.setInt(5, pueblo.getNum_h());
			pst.setString(6, pueblo.getRanking());
			pst.setInt(7, pueblo.getId());

			int insert = pst.executeUpdate();

			if (insert > 0) {
				resultado = "1";
				System.out.println("Se EDITO el pueblo magico " + insert);
			} else {
				resultado = "0";
				System.out.println("No se EDITO el pueblo magico " + insert);
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error al EDITAR");
		}

		return resultado;
	}

	@Override
	public String eliminar(Object obj) {
		pueblo = (Pueblos) obj;

		// crear la conexion con un object
		Connection cone;
		// abrir la conexion --> PreparedStament --> mediante una delcaracion preparda
		PreparedStatement pst;
		// preparar la sentencia
		String query = "DELETE FROM PUEBLOS WHERE ID=?";
		String resultado = null;
		try {
			// registrar la clase --> metodo forName() de la class --> me permite traer el
			// controlador
			Class.forName(bd.getDriver()); // permite registra la clase del controlador
			// abrir el objeto onexion --> de la clase DriveManager
			cone = DriverManager.getConnection(bd.getUrl(), bd.getUsuario(), bd.getPassword());
			// ejecuta la sentencia sql
			pst = cone.prepareStatement(query);

			pst.setInt(1, pueblo.getId());

			int insert = pst.executeUpdate();

			if (insert > 0) {
				resultado = "1";
				System.out.println("Se ELIMINO el pueblo magico " + insert);
			} else {
				resultado = "0";
				System.out.println("No se ELIMINO el pueblo magico " + insert);
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error al ELIMINAR");
		}

		return resultado;
	}

	@Override
	public Object buscar(Object obj) {
		pueblo = (Pueblos) obj;

		// crear la conexion con un object
		Connection cone;
		// abrir la conexion --> PreparedStament --> mediante una delcaracion preparda
		PreparedStatement pst;
		// preparar la sentencia
		String query = "SELECT * FROM PUEBLOS WHERE ID=" + pueblo.getId();

		ResultSet rs = null;
		try {
			// registrar la clase --> metodo forName() de la class --> me permite traer el
			// controlador
			Class.forName(bd.getDriver()); // permite registra la clase del controlador
			// abrir el objeto onexion --> de la clase DriveManager
			cone = DriverManager.getConnection(bd.getUrl(), bd.getUsuario(), bd.getPassword());
			// ejecuta la sentencia sql
			pst = cone.prepareStatement(query);
			rs = pst.executeQuery(query);
			while (rs.next()) {
				pueblo = new Pueblos(rs.getInt("ID"), rs.getString("NOMBRE"), rs.getString("MUNICIPIO"),
						rs.getString("ESTADO"), rs.getString("PAIS"), rs.getInt("NUM_H"), rs.getString("RANKING"));
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error al BUSCAR");
		}

		return pueblo;
	}

	@Override
	public List listar() {
		List<Object> lista = new ArrayList<Object>();

		// crear la conexion con un object
		Connection cone;
		// abrir la conexion --> PreparedStament --> mediante una delcaracion preparda
		PreparedStatement pst;
		// preparar la sentencia
		String query = "SELECT * FROM PUEBLOS";

		ResultSet rs = null;
		try {
			// registrar la clase --> metodo forName() de la class --> me permite traer el
			// controlador
			Class.forName(bd.getDriver()); // permite registra la clase del controlador
			// abrir el objeto onexion --> de la clase DriveManager
			cone = DriverManager.getConnection(bd.getUrl(), bd.getUsuario(), bd.getPassword());
			// ejecuta la sentencia sql
			pst = cone.prepareStatement(query);
			rs = pst.executeQuery(query);
			while (rs.next()) {
				lista.add(new Pueblos(rs.getInt("ID"), rs.getString("NOMBRE"), rs.getString("MUNICIPIO"),
						rs.getString("ESTADO"), rs.getString("PAIS"), rs.getInt("NUM_H"), rs.getString("RANKING")));
			}
		

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error al BUSCAR");
		}

		return lista;
	}
}
