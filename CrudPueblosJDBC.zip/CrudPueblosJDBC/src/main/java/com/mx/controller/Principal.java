package com.mx.controller;

import com.mx.dao.ImplementacionDao;
import com.mx.dominio.Pueblos;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ImplementacionDao imp = new ImplementacionDao();
		
		// meotodo mostrar 
		System.out.println("La lista contien -->"+imp.listar());
		// metodo guardar 
		
		Pueblos pueblo = new Pueblos(5, "quetzalan", "puebla", "puebla", "mexico", 30000, "2 lugar");
		imp.guardar(pueblo);
		System.out.println("La lista contien -->"+imp.listar());
		
		// buscar 
		
		pueblo = new Pueblos(2);
		pueblo = (Pueblos) imp.buscar(pueblo);
		System.out.println("Se encontro el pueblo "+pueblo);
		
		// editar --> primero buscamos 
		pueblo = new Pueblos(2);
		pueblo = (Pueblos) imp.buscar(pueblo);
		System.out.println("Se encontro el pueblo "+pueblo);
		pueblo.setNombre("atlixco");
		imp.editar(pueblo);
		System.out.println("La lista contien -->"+imp.listar());
		
		// eliminar 
		imp.eliminar(new Pueblos(5));
		System.out.println("La lista contien -->"+imp.listar());
	}

}
