package com.mx.webService;

import java.util.List;

import javax.print.attribute.standard.Media;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.mx.dao.ImplementacionDao;
import com.mx.dominio.Pueblos;
import com.mx.general.Resultado;

@Path("WebServicePueblos")
public class WebServicePueblos {

	// para realizar peticiones mediante HTTP --> get, post, delete, put, view...
	ImplementacionDao imp = new ImplementacionDao();

	// JSON --> {} --> atrinbuto: valor

	// url = url del servidor + nombre del proyecto en minusculas(web.xml)+path de
	// clase + path del metodo
	// http://localhost:9002/CrudPueblosJDBC/crudPueblosJDBC/WebServicePueblos/listar

	@Path("listar")
	@GET
	@Consumes({ MediaType.APPLICATION_JSON }) // estereotipos o anotacion que permiten desrrollar y consumir una web
												// service --> Rest -> JSON
	@Produces({ MediaType.APPLICATION_JSON })
	public List<Pueblos> listar() {

		List<Pueblos> listaPueblos = imp.listar();
		double suma = 0;
		for(Pueblos p : listaPueblos) {
			
			suma += p.getNum_h();
			System.out.println("Total habitantes "+suma);
		}
		

		return listaPueblos;
	}
	
	// http://localhost:9002/CrudPueblosJDBC/crudPueblosJDBC/WebServicePueblos/totalH
	@Path("totalH")
	@GET
	@Consumes({ MediaType.APPLICATION_JSON }) // estereotipos o anotacion que permiten desrrollar y consumir una web
												// service --> Rest -> JSON
	@Produces({ MediaType.APPLICATION_JSON })
	public Double totalH() {

		List<Pueblos> listaPueblos = imp.listar();
		double suma = 0;
		for(Pueblos p : listaPueblos) {
			
			suma += p.getNum_h();
			System.out.println("Total habitantes "+suma);
		}
		

		return suma;
	}

	// guardar
	// http://localhost:9002/CrudPueblosJDBC/crudPueblosJDBC/WebServicePueblos/guardar
	@Path("guardar")
	@POST
	@Consumes({ MediaType.APPLICATION_JSON }) // estereotipos o anotacion que permiten desrrollar y consumir una web
												// service --> Rest -> JSON
	@Produces({ MediaType.APPLICATION_JSON })
	public Resultado guardar(Pueblos pueblo) {

		Resultado rs = new Resultado();
		rs.setObj(pueblo);

		String p = imp.guardar(pueblo);

		if (p.equals("1")) {
			rs.setMensaje("Se guardo el pueblo magico");
			rs.setRespuesta(p);
		} else {
			rs.setMensaje("No se guardo el pueblo magico");
			rs.setRespuesta(p);
		}

		return rs;
	}

	// editar

	// http://localhost:9002/CrudPueblosJDBC/crudPueblosJDBC/WebServicePueblos/editar
	@Path("editar")
	@POST
	@Consumes({ MediaType.APPLICATION_JSON }) // estereotipos o anotacion que permiten desrrollar y consumir una web
												// service --> Rest -> JSON
	@Produces({ MediaType.APPLICATION_JSON })
	public Resultado editar(Pueblos pueblo) {

		Resultado rs = new Resultado();
		rs.setObj(pueblo);

		String p = imp.editar(pueblo);

		if (p.equals("1")) {
			rs.setMensaje("Se edito el pueblo magico");
			rs.setRespuesta(p);
		} else {
			rs.setMensaje("No se edito el pueblo magico");
			rs.setRespuesta(p);
		}

		return rs;

	}

	// editar

	// http://localhost:9002/CrudPueblosJDBC/crudPueblosJDBC/WebServicePueblos/eliminar
	@Path("eliminar")
	@POST
	@Consumes({ MediaType.APPLICATION_JSON }) // estereotipos o anotacion que permiten desrrollar y consumir una web
												// service --> Rest -> JSON
	@Produces({ MediaType.APPLICATION_JSON })
	public Resultado eliminar(Pueblos pueblo) {

		Resultado rs = new Resultado();
		rs.setObj(pueblo);

		String p = imp.eliminar(pueblo);

		if (p.equals("1")) {
			rs.setMensaje("Se elimino el pueblo magico");
			rs.setRespuesta(p);
		} else {
			rs.setMensaje("No se elimino el pueblo magico");
			rs.setRespuesta(p);
		}

		return rs;

	}
	// http://localhost:9002/CrudPueblosJDBC/crudPueblosJDBC/WebServicePueblos/buscar	
	// buscar 
	@Path("buscar")
	@POST
	@Consumes({ MediaType.APPLICATION_JSON }) // estereotipos o anotacion que permiten desrrollar y consumir una web
												// service --> Rest -> JSON
	@Produces({ MediaType.APPLICATION_JSON })
	public Pueblos buscar(Pueblos pueblo) {
	
		pueblo = (Pueblos) imp.buscar(pueblo);
		return pueblo ;
	}
	

}
