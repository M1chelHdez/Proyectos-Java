package com.mx.Celulares.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mx.Celulares.dominio.Celulares;
import com.mx.Celulares.service.Implementacion;


@RestController
@RequestMapping(path = "CelularesWs")
@CrossOrigin("*")
public class CelularesWs {

	@Autowired
	Implementacion imp;

	// http://localhost:9002/CelularesWs/listar
	@RequestMapping(path = "listar")
	public ResponseEntity<?> listar() {
		List<Celulares> lista = new ArrayList<>();
		lista = imp.listar();
		return ResponseEntity.status(HttpStatus.CREATED).body(lista);

	}

	// http://localhost:9002/CelularesWs/guardar
	@RequestMapping(path = "guardar")
	public ResponseEntity<String> guardar(@RequestBody Celulares celulares) {
		String mensaje = null;

		// Verificar si la marca es válida
		if (celulares.getMarca().equals("XIAOMI") || celulares.getMarca().equals("SAMSUNG")
				|| celulares.getMarca().equals("IPHONE") || celulares.getMarca().equals("ALCATEL")
				|| celulares.getMarca().equals("MOTOROLA")) {

			// Verificar si la marca ya existe en la base de datos antes de guardar
			List<Celulares> celularesConMarca = imp.buscarMarca(celulares.getMarca());

			if (!celularesConMarca.isEmpty()) {
				mensaje = "La marca ya existe en la base de datos. No se puede guardar.";
			} else {
				imp.guardar(celulares);
				mensaje = "Se guardó el celular " + celulares.getModelo();
			}
		} else {
			mensaje = "Marca no válida";
		}

		return new ResponseEntity<String>(mensaje, HttpStatus.OK);
	}

	// http://localhost:9002/CelularesWs/editar
	@RequestMapping(path = "editar")
	public ResponseEntity<String> editar(@RequestBody Celulares celulares) {
		String mensaje = null;

		// Verificar si la marca es válida
		if (celulares.getMarca().equals("XIAOMI") || celulares.getMarca().equals("SAMSUNG")
				|| celulares.getMarca().equals("IPHONE") || celulares.getMarca().equals("ALCATEL")
				|| celulares.getMarca().equals("MOTOROLA")) {

			imp.editar(celulares);
			mensaje = "Se editó el celular " + celulares.getModelo();
		} else {
			mensaje = "Marca no válida";
		}

		return new ResponseEntity<String>(mensaje, HttpStatus.OK);
	}

	// http://localhost:9002/CelularesWs/eliminar
	@RequestMapping("eliminar")
	public ResponseEntity<String> eliminar(@RequestBody Celulares celulares) {
		try {
			imp.eliminar(celulares);
			return ResponseEntity.status(HttpStatus.OK).body("Celular eliminado");
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Error al eliminar empleado(s): " + e.getMessage());
		}
	}

	// http://localhost:9002/CelularesWs/buscar
	@RequestMapping(path = "buscar")
	public ResponseEntity<?> buscar(@RequestBody Celulares celulares) {
		String marca = celulares.getMarca();
		String mensaje = null;
		List<Celulares> encontrados = imp.buscarMarca(marca);

		if (!encontrados.isEmpty()) {
			return ResponseEntity.status(HttpStatus.OK).body(encontrados);
		} else {
			mensaje = "No se encontró el celular";
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mensaje);
		}
	}

	// http://localhost:9002/CelularesWs/ganancias
	@RequestMapping(path = "ganancias")
	public ResponseEntity<Map<String, Double>> ganancias() {
		// Obtener la lista de todos los celulares
		List<Celulares> todosLosCelulares = imp.listar();

		// Crear un mapa para almacenar las ganancias por marca
		Map<String, Double> gananciasPorMarca = new HashMap<>();

		// Calcular las ganancias por marcaf
		for (Celulares celular : todosLosCelulares) {
			String marca = celular.getMarca();
			double ganancias = celular.getGanancias();

			// Si la marca ya está en el mapa, suma las ganancias existentes
			if (gananciasPorMarca.containsKey(marca)) {
				double gananciasActuales = gananciasPorMarca.get(marca);
				gananciasPorMarca.put(marca, gananciasActuales + ganancias);
			} else {
				// Si la marca no está en el mapa, agrega las ganancias
				gananciasPorMarca.put(marca, ganancias);
			}
		}

		return new ResponseEntity<>(gananciasPorMarca, HttpStatus.OK);
	}
	
	// http://localhost:9002/CelularesWs/listarPorMarca
	@RequestMapping(path = "listarPorMarca")
	public ResponseEntity<?> listarPorMarca(@RequestBody Celulares celulares) {
	    // Utilizar el servicio para buscar los celulares por marca
	    List<Celulares> celularesPorMarca = imp.listarMarca(celulares);

	    // Verificar si se encontraron celulares para la marca especificada
	    if (!celularesPorMarca.isEmpty()) {
	        return ResponseEntity.status(HttpStatus.OK).body(celularesPorMarca);
	    } else {
	        String mensaje = "No se encontraron celulares para la marca especificada";
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mensaje);
	    }
	}
	
	// http://localhost:9002/CelularesWs/realizarPedido
	@RequestMapping(path = "realizarPedido")
	public ResponseEntity<String> realizarPedido(@RequestBody Celulares celulares) {
	    String marcaPedido = celulares.getMarca();
	    int cantidadPedido = celulares.getStockInventario();

	    // Utilizar el servicio para buscar los celulares por marca
	    List<Celulares> celularesPorMarca = imp.listarMarca(celulares);

	    // Verificar si se encontraron celulares para la marca especificada
	    if (!celularesPorMarca.isEmpty()) {
	        Celulares celularMarca = celularesPorMarca.get(0);
	        int stockActual = celularMarca.getStockInventario();

	        // Verificar si la cantidad en stock es suficiente para el pedido
	        if (cantidadPedido >= 0) {
	            // Actualizar la cantidad en stock, incluso si llega a 0
	            celularMarca.setStockInventario(cantidadPedido);
	            imp.editar(celularMarca); // Guardar el cambio en la base de datos

	            return ResponseEntity.status(HttpStatus.OK).body("Pedido realizado con éxito. Stock actualizado.");
	        } else {
	            String mensaje = "La cantidad del pedido no es válida";
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mensaje);
	        }
	    } else {
	        String mensaje = "No se encontró la marca";
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mensaje);
	    }
	}



	

}
