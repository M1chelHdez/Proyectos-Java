package com.mx.Celulares.dominio;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "VENTA_CELULARES")
@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@Getter
@Setter
public class Celulares {
	
	/*
	 * CREATE TABLE VENTA_CELULARES(
ID NUMBER PRIMARY KEY,
MARCA NVARCHAR2(50),
MODELO NVARCHAR2(50),
COLOR NVARCHAR2(50),
RAM NVARCHAR2(50), --> 4 RAM
TAMANO NVARCHAR2(50),
PROCESADOR NVARCHAR2(50),
PRECIO_COMPRA NUMBER,
PRECIO_VENTA NUMBER,
CANTIDAD_VENDIDA NUMBER,
FECHA_VENTA DATE,
STOCK_INVENTARIO NUMBER,
GANANCIAS NUMBER,
CHECK (MARCA IN ('XIAOMI','SAMSUM','IPHONE','ALCATEL','MOTOROLA'))
);
	 */
	
	
	@Id
	@Column
	int id;
	@Column
	String marca;
	@Column
	String modelo;
	@Column
	String color;
	@Column
	String ram;
	@Column
	String tamano;
	@Column
	String procesador;
	@Column(name = "PRECIO_COMPRA")
	double precioCompra;
	@Column(name = "PRECIO_VENTA")
	double precioVenta;
	@Column(name = "CANTIDAD_VENDIDA")
	int cantidadVendida;
	@Column(name = "FECHA_VENTA")
	Date fechaVenta;
	@Column(name = "STOCK_INVENTARIO")
	int stockInventario;
	@Column
	double ganancias;
	
	 
}
