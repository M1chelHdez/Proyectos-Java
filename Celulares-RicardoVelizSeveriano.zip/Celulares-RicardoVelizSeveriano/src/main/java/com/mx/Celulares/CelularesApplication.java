package com.mx.Celulares;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CelularesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CelularesApplication.class, args);
	}

}
