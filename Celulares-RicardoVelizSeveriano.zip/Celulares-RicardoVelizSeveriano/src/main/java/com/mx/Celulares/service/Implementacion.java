
package com.mx.Celulares.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mx.Celulares.dao.CelularesDao;
import com.mx.Celulares.dominio.Celulares;

@Service
public class Implementacion implements Metodos {

	@Autowired
	CelularesDao dao;

	@Override
	public void guardar(Celulares celulares) {
		dao.save(celulares);
	}

	@Override
	public void editar(Celulares celulares) {
		dao.save(celulares);

	}

	@Override
	public void eliminar(Celulares celulares) {
		List<Celulares> elim = new ArrayList<>();
		for (Celulares c : listar()) {
			if (c.getModelo().equals(celulares.getModelo()) || c.getMarca().equals(celulares.getMarca())) {
				elim.add(c);
			}
		}
		for (Celulares c : elim) {
			dao.delete(c);
		}

	}

	@Override
	public Celulares buscar(Celulares ccelulares) {
		return dao.findById(ccelulares.getId()).orElseThrow(() -> new RuntimeException("No existe el celular"));
	}

	@Override
	public List<Celulares> listarMarca(Celulares celulares) {
		return dao.findAllByMarca(celulares.getMarca());
	}

	@Override
	public List<Celulares> listar() {
		return (List<Celulares>) dao.findAll();
	}

	public List<Celulares> buscarModelo(String modelo) {
		List<Celulares> celu = dao.findAllByModelo(modelo);
		return celu;
	}

	public List<Celulares> buscarMarca(String marca) {
		List<Celulares> celu = dao.findAllByMarca(marca);
		return celu;
	}

}
