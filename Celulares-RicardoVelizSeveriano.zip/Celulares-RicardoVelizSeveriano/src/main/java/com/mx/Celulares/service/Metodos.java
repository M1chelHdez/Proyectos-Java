package com.mx.Celulares.service;

import java.util.List;

import com.mx.Celulares.dominio.Celulares;

public interface Metodos {

	public void guardar(Celulares celulares);

	public void editar(Celulares celulares);

	public void eliminar(Celulares celulares);

	public Celulares buscar(Celulares ccelulares);

	public List<Celulares> listarMarca(Celulares celulares);

	public List<Celulares> listar();

}
