package com.mx.Celulares.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mx.Celulares.dominio.Celulares;

@Repository
public interface CelularesDao extends CrudRepository<Celulares, Integer> {

	List<Celulares> findAllByMarca(String marca);

	List<Celulares> findAllByModelo(String modelo);

	void deleteByModelo(String modelo);

	void deleteByMarca(String marca);

}
