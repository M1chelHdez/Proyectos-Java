package mx.com.invex.client.email.api;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import mx.com.invex.components.api.model.Addressee;
import mx.com.invex.components.api.model.dto.request.EmailDataRequest;
import mx.com.invex.components.api.model.dto.request.MailSendRequestCpcTpcProcess;
import mx.com.invex.components.api.model.dto.response.WebResponse;
import mx.com.invex.components.utils.UnirestMapperInit;
import mx.com.invex.core.exception.internal.InternalException;

/**
 * Created by Armando Muñoz on 08/02/2018.
 */
public class EmailClientTest {

	private static final String ENV_PROPERTY = "global.mirth2";
	private static final String TEST_SERVER_URL = "https://invd-pxy-mirth2-01.invexbt.com/";

	@Before
	public void setEnvProperty() {
		System.setProperty(ENV_PROPERTY, TEST_SERVER_URL);
		new UnirestMapperInit();
	}

	@Test
	public void sendEmail() throws InternalException {

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("date", "04/06/2019");
		parameters.put("email", "jamirandaf@invex.com");
		parameters.put("name", "Alejandro Miranda");

		Addressee addressee = new Addressee.Builder()
				.email("JAMIRANDAF@invex.com")
				.account("CA2ABED97904B3048F10E8FE5633D7C59FD53DD88D4A22AC0DF96CE3A398CA3C6EC8ED4F3FFC77032493CDAC04FEDDFF")
				.parameters(parameters)
				.build();

		List<Addressee> addressees = new ArrayList<>();
		addressees.add(addressee);

		EmailDataRequest emailDataRequest = new EmailDataRequest.Builder()
				.fromName("Invex")
				.fromEmail("boletin@invex.com")
				.subject("Correo de prueba")
				.cpcCode("INO")
				.tpcCode("VS")
				.processInternalKey("ACC_CERT_REQ")
				.addressee(addressees)
				.build();	
    
		EmailClient emailClient = new EmailClient();
		WebResponse webResponse = emailClient.sendMail(emailDataRequest);
		assertNotNull(webResponse);
	}
	
	@Test
	public void sendEmailOld() throws InternalException {
	
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("date", "04/06/2019");
		parameters.put("email", "jamirandaf@invex.com");
		parameters.put("name", "Alejandro Miranda");
		
		MailSendRequestCpcTpcProcess mailSendRequestCpcTpcProcess = new MailSendRequestCpcTpcProcess.Builder()
				.fromEmail("boletin@invex.com")
				.fromName("Invex")
				.subject("Correo de prueba")
				.email("JAMIRANDAF@invex.com")
				.account("CA2ABED97904B3048F10E8FE5633D7C59FD53DD88D4A22AC0DF96CE3A398CA3C6EC8ED4F3FFC77032493CDAC04FEDDFF")
				.cpcCode("INO")
				.tpcCode("VS")
				.processInternalKey("ACC_CERT_REQ")
				.parameters(parameters)
				.build();
    
		EmailClient emailClient = new EmailClient();
		WebResponse webResponse = emailClient.sendMail(mailSendRequestCpcTpcProcess);
		assertNotNull(webResponse);
	}

}