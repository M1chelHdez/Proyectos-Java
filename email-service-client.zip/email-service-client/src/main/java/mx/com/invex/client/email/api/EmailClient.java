package mx.com.invex.client.email.api;

import mx.com.invex.components.api.model.dto.request.BaseHttpRequest;
import mx.com.invex.components.api.model.dto.request.EmailDataRequest;
import mx.com.invex.components.api.model.dto.request.MailSendRequestCpcTpcProcess;
import mx.com.invex.components.api.model.dto.request.Post;
import mx.com.invex.components.api.model.dto.response.WebResponse;
import mx.com.invex.core.exception.internal.InternalException;
import mx.com.invex.lib.api.client.RestClient;
import mx.com.invex.lib.support.enums.Server;

/**
 * @author Armando Munoz
 */
public class EmailClient extends RestClient {

	private static final String CONTEXT = "/email-backend/api/";

	public EmailClient() {
		super(CONTEXT,  Server.MIRTH_3);
	}

	/**
	 * @deprecated (since 06/2019)
	 * @param mailSendRequestCpcTpcProcess
	 * @param trackingHeader
	 * @throws InternalException
	 */
	@Deprecated
	public WebResponse sendMail(MailSendRequestCpcTpcProcess mailSendRequestCpcTpcProcess)
			throws InternalException {
		BaseHttpRequest request = new Post(EndPoint.SEND_MAIL_TPC_CPC.getEndPointPath())
				.body(mailSendRequestCpcTpcProcess);
		return invokeService(request, WebResponse.class).getBody();
	}

	/**
	 * @param emailDataRequest
	 * @param trackingHeader
	 * @throws InternalException
	 */
	public WebResponse sendMail(EmailDataRequest emailDataRequest) throws InternalException {
		BaseHttpRequest request = new Post(EndPoint.SEND_MAIL.getEndPointPath()).body(emailDataRequest);
		return invokeService(request, WebResponse.class).getBody();
	}

	enum EndPoint {

		SEND_MAIL_TPC_CPC("/mail/v2/sendMail"), SEND_MAIL("/mail/v3/sendMail");

		private String endPointPath;

		EndPoint(String endPointPath) {
			this.endPointPath = endPointPath;
		}

		public String getEndPointPath() {
			return endPointPath;
		}
	}
}
