# Invex EMAIL Rest Client
Proyecto base para generar un cliente Rest   

* Versión: **1.0.0**
* Fecha: **2017**

* Java 1.8
* Jboss EAP 7.0